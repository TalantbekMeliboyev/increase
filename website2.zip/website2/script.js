let num1 = Math.ceil(Math.random() * 10);
let num2 = Math.ceil(Math.random() * 10);

let questionEl = document.getElementById("question");

let inputEl = document.getElementById("input");

let formEl = document.getElementById("form");

let scoreEl = document.getElementById("score");

let score = JSON.parse(localStorage.getItem("score"));

if (!score) {
    score = 0;
}

scoreEl.innerText = `score: ${score}`;

questionEl.innerText = `${num1} ni  ${num2} ga ko'paytirish nima?`;

let correctAns = num1 * num2;

formEl.addEventListener("submit", () => {
    const userAns = +inputEl.value;
    if (userAns === correctAns) {
    score++;
        updateLocalStorage();
    } else {
    score--;
        updateLocalStorage();
    }
});

function updateLocalStorage() {
    localStorage.setItem("score", JSON.stringify(score));
}
